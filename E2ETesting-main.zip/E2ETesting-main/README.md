# E2ETesting

.Net End to end testing project, using Playwright, SpecFlow and XUnit.

Typically you would add this project folder as an existing project to the solution you are testing.